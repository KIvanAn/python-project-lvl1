"""Init brain games package."""
