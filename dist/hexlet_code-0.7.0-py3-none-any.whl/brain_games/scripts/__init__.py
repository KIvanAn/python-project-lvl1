"""Init scripts package."""
